실행방법
python query_analysis_v02.py
