실행방법
python get_LAT_feature.py release_model -lstm_type single -enhanced_mention -data_setup joint -add_crowd -multitask -mode test -reload_model_name release_model -eval_data crowd/test3.json -load
